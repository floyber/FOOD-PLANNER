// server.js
const express = require('express');
const cors = require('cors');
const path = require('path'); // Puedes quitarlo si no lo usas
require('dotenv').config(); // Cargar las variables de entorno al inicio

// ¡SOLO UNA VEZ! Importar la conexión a la base de datos y la función de conexión
const { connectDB } = require('./config/db'); // Esta es la LÍNEA 8 en tu error, asegúrate que solo esté aquí.

const app = express();

// Cargar rutas (asegúrate de que existan estos archivos y nombres)
const authRouter = require('./routes/auth'); // Si es para registro/login
const calendarioRouter = require('./routes/calendario');
// Si tienes estos archivos, descomenta e importa:
const loginRouter = require('./routes/login'); // Si tienes un archivo login.js separado
const passwordRoute = require('./routes/password'); // Si tienes un archivo password.js separado
const listacomprasRouter = require('./routes/listacompras'); // Si tienes un archivo listacompras.js separado

// Middleware para CORS y parseo de JSON
app.use(cors());
app.use(express.json());

// Montar rutas
app.use('/api', authRouter);
app.use('/api', calendarioRouter);
// Si usas las otras rutas:
app.use('/api', loginRouter);
app.use('/api', passwordRoute);
app.use('/api', listacomprasRouter);


// Ruta de prueba (opcional)
app.get('/', (req, res) => {
    res.send('Servidor funcionando correctamente');
});

// Iniciar el servidor
const PORT = process.env.PORT || 3000;

// Asegurarse de que la conexión a la base de datos esté lista antes de iniciar el servidor
connectDB().then(() => {
    app.listen(PORT, () => {
        console.log(`Servidor escuchando en el puerto ${PORT}`);
    });
}).catch(err => {
    console.error('Error FATAL al iniciar el servidor - Conexión a la base de datos fallida:', err);
    process.exit(1); // Salir de la aplicación si no se puede conectar a la DB
});