
const nodemailer = require("nodemailer");
require('dotenv').config();

// Configuración del transporter para Gmail SMTP
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

/**
 * Envía un correo de restablecimiento de contraseña.
 * @param {string} to - Correo destino
 * @param {string} resetUrl - URL de restablecimiento
 * @returns {Promise<boolean>}
 */
const sendResetPasswordEmail = async (to, resetUrl) => {  
  try {
    const mailOptions = {
      from: process.env.SMTP_USER,
      to: to,
      subject: "Restablecimiento de contraseña",
      html: `
        <b>Solicitaste el restablecimiento de tu contraseña</b>
        <p>Haz click en el siguiente enlace:</p>
        <a href="${resetUrl}" target="_blank">Restablecer contraseña</a>
        <p>Este enlace expira en 1 hora.</p>
        <p>Si no solicitaste este cambio, ignora este correo.</p>
      `,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log("Correo enviado exitosamente:", info.messageId);
    return true;
  } catch (error) {
    console.error("Error al enviar el correo:", error);
    return false;
  }
};

module.exports = {
  transporter,
  sendResetPasswordEmail,
};
