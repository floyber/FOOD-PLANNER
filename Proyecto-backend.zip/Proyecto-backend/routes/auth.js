const express = require('express');
const router = express.Router();
const { pool } = require('../config/db'); // ¡Ruta correcta para acceder a db.js!
const bcrypt = require('bcrypt');

// Ruta para crear un nuevo usuario (POST /api/Usuario)
router.post('/Usuario', async (req, res) => {
    const { nombre_completo, correo_electronico, contraseña } = req.body;

    // Validación básica de campos
    if (!nombre_completo || !correo_electronico || !contraseña) {
        return res.status(400).send({ error: 'Todos los campos son obligatorios.' });
    }

    try {
        // 1. Verificar si el correo electrónico ya está registrado
        const [existingUser] = await pool.query('SELECT * FROM Usuario WHERE correo_electronico = ? LIMIT 1', [correo_electronico]);
        if (existingUser.length > 0) {
            return res.status(409).send({ error: 'El correo electrónico ya está registrado.' });
        }

        // 2. Hashear la contraseña
        const hashedPassword = await bcrypt.hash(contraseña, 10);

        // 3. Insertar el nuevo usuario en la base de datos
        const [result] = await pool.query('INSERT INTO Usuario (nombre_completo, correo_electronico, contraseña) VALUES (?, ?, ?)', [nombre_completo, correo_electronico, hashedPassword]);

        // 4. Enviar respuesta de éxito
        return res.status(201).json({
            message: 'Usuario creado exitosamente',
            userId: result.insertId,
            nombre_completo,
            correo_electronico
        });
    } catch (err) {
        console.error('Error al crear el usuario:', err);
        return res.status(500).send({ error: 'Error interno del servidor.' });
    }
});





module.exports = router;