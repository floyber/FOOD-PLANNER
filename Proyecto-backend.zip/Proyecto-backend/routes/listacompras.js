const express = require('express');
const router = express.Router();
// ¡CAMBIO AQUÍ! Necesitas desestructurar el 'pool' del objeto exportado
const { pool } = require('../config/db'); // Asegúrate de que la ruta a tu db.js sea correcta

// 1. Ruta para obtener todos los ítems de la lista de compras (GET /api/listacompras)
router.get('/listacompras', async (req, res) => {
    try {
        const [items] = await pool.query('SELECT * FROM ListaCompras ORDER BY categoria, texto');
        return res.status(200).json(items);
    } catch (err) {
        console.error('Error al obtener la lista de compras:', err);
        return res.status(500).send({ error: 'Error interno del servidor' });
    }
});

// 2. Ruta para añadir un nuevo ítem a la lista de compras (POST /api/listacompras)
router.post('/listacompras', async (req, res) => {
    const { texto, categoria } = req.body; // 'completado' y 'fecha' se manejan en la DB

    if (!texto) {
        return res.status(400).send({ error: 'El texto del ítem es obligatorio.' });
    }

    try {
        const [result] = await pool.query(
            'INSERT INTO ListaCompras (texto, categoria) VALUES (?, ?)',
            [texto, categoria || 'otros'] // Si no se envía categoría, usa 'otros'
        );
        return res.status(201).json({
            message: 'Ítem añadido exitosamente',
            id: result.insertId,
            texto,
            categoria,
            completado: false // Por defecto es false
        });
    } catch (err) {
        console.error('Error al añadir ítem a la lista de compras:', err);
        return res.status(500).send({ error: 'Error interno del servidor' });
    }
});

// 3. Ruta para actualizar el estado de un ítem (completado/pendiente) (PATCH /api/listacompras/:id)
router.patch('/listacompras/:id', async (req, res) => {
    const { id } = req.params;
    const { completado } = req.body;

    // Se valida que 'completado' sea un booleano
    if (typeof completado !== 'boolean') {
        return res.status(400).send({ error: 'El campo "completado" debe ser un booleano.' });
    }

    try {
        const [result] = await pool.query(
            'UPDATE ListaCompras SET completado = ? WHERE id = ?',
            [completado, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).send({ error: 'Ítem no encontrado.' });
        }
        return res.status(200).json({ message: 'Estado del ítem actualizado exitosamente.' });
    } catch (err) {
        console.error('Error al actualizar ítem de la lista de compras:', err);
        return res.status(500).send({ error: 'Error interno del servidor' });
    }
});

// 4. Ruta para eliminar un ítem (DELETE /api/listacompras/:id)
router.delete('/listacompras/:id', async (req, res) => {
    const { id } = req.params;

    try {
        const [result] = await pool.query('DELETE FROM ListaCompras WHERE id = ?', [id]);

        if (result.affectedRows === 0) {
            return res.status(404).send({ error: 'Ítem no encontrado.' });
        }
        return res.status(200).send({ message: 'Ítem eliminado exitosamente.' });
    } catch (err) {
        console.error('Error al eliminar ítem de la lista de compras:', err);
        return res.status(500).send({ error: 'Error interno del servidor' });
    }
});

// 5. Ruta para eliminar todos los ítems (DELETE /api/listacompras)
router.delete('/listacompras', async (req, res) => {
    try {
        await pool.query('DELETE FROM ListaCompras');
        return res.status(200).send({ message: 'Todos los ítems de la lista de compras han sido eliminados.' });
    } catch (err) {
        console.error('Error al eliminar todos los ítems de la lista de compras:', err);
        return res.status(500).send({ error: 'Error interno del servidor' });
    }
});

module.exports = router;