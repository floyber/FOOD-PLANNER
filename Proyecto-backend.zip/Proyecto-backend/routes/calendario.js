const express = require('express'); // ¡Añade esta línea!
const router = express.Router();    // ¡Añade esta línea!
const { pool } = require('../config/db'); // Asegúrate de que la ruta sea correcta a tu db.js



// Ruta para obtener todos los eventos del calendario (GET /api/calendario)
router.get('/calendario', async (req, res) => {
    try {
        // En un escenario real, querrías filtrar por usuario (ej. WHERE user_id = ?).
        // Por ahora, obtenemos todos los eventos.
        const [events] = await pool.query('SELECT * FROM Calendario ORDER BY fecha, tipo_comida');
        return res.status(200).json(events);
    } catch (err) {
        console.error('Error al obtener el calendario:', err);
        return res.status(500).send({ error: 'Error interno del servidor' });
    }
});

// Ruta para añadir una nueva comida/evento al calendario (POST /api/calendario)
router.post('/calendario', async (req, res) => {
    const { fecha, tipo_comida, nombre_comida, ingredientes, notas } = req.body;

    // Validación básica
    if (!fecha || !tipo_comida || !nombre_comida) {
        return res.status(400).send({ error: 'Fecha, tipo de comida y nombre de la comida son obligatorios.' });
    }

    try {
        const [result] = await pool.query(
            'INSERT INTO Calendario (fecha, tipo_comida, nombre_comida, ingredientes, notas) VALUES (?, ?, ?, ?, ?)',
            [fecha, tipo_comida, nombre_comida, JSON.stringify(ingredientes), notas] // Guardamos ingredientes como JSON string
        );
        return res.status(201).json({
            message: 'Comida añadida al calendario exitosamente',
            id: result.insertId,
            fecha,
            tipo_comida,
            nombre_comida
        });
    } catch (err) {
        console.error('Error al añadir comida al calendario:', err);
        return res.status(500).send({ error: 'Error interno del servidor' });
    }
});

// Ruta para eliminar una comida/evento del calendario (DELETE /api/calendario/:id)
router.delete('/calendario/:id', async (req, res) => {
    const { id } = req.params; // Capturamos el ID de los parámetros de la URL

    try {
        const [result] = await pool.query('DELETE FROM Calendario WHERE id = ?', [id]);

        if (result.affectedRows === 0) {
            return res.status(404).send({ error: 'Comida no encontrada en el calendario.' });
        }
        return res.status(200).send({ message: 'Comida eliminada del calendario exitosamente.' });
    } catch (err) {
        console.error('Error al eliminar comida del calendario:', err);
        return res.status(500).send({ error: 'Error interno del servidor' });
    }
});

module.exports = router; // Ya tenías esta línea, ¡es vital!