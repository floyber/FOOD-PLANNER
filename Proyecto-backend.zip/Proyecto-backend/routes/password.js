const express = require('express');
const router = express.Router();
const db = require('../config/db');
const crypto = require('crypto');
const bcrypt = require('bcrypt');
const { sendResetPasswordEmail } = require('../config/email');
require('dotenv').config();

router.post('/olvide_contrasena', (req, res) => {
    const { email } = req.body;

    // Verificar token y restablecer contraseña


    if (!email) {
        return res.status(400).json({ error: 'El email es requerido' });
    }

    db.query('SELECT * FROM Usuario WHERE email = ?', [email], (err, results) => {
        if (err) {
            console.error('Error al verificar el email', err);
            return res.status(500).json({ error: 'Error interno del servidor' });
        }

        // Por seguridad, siempre respondemos igual aunque el correo no exista
        if (results.length === 0) {
            return res.status(200).json({ message: 'Si el email existe, recibirás una URL para restablecer tu contraseña' });
        }

        const Usuario = results[0];
        const token = crypto.randomBytes(20).toString('hex');
        const expirationDate = new Date(Date.now() + 3600000); // 1 hora

        db.query(
            'UPDATE Usuario SET reset_token = ?, reset_token_expiration = ? WHERE id = ?',
            [token, expirationDate, Usuario.id],
            async (updateErr) => {
                if (updateErr) {
                    console.error('Error al realizar la actualización', updateErr);
                    return res.status(500).json({ error: 'Error interno del servidor' });
                }

                try {
                    await sendResetPasswordEmail(email, token);
                    return res.status(200).json({ message: 'Si el email existe, recibirás una URL para restablecer tu contraseña' });
                } catch (emailErr) {
                    console.error('Error al enviar el email', emailErr);
                    return res.status(500).json({ error: 'No se pudo enviar el correo de restablecimiento' });
                }
            }
        );
    });
});

router.post('/restablecer_contrasena', async (req, res) => {
  const { token, nueva_contraseña } = req.body;
  
  if (!token || !nueva_contraseña) {
    return res.status(400).send('Faltan datos obligatorios');
  }
  
  // Validar longitud mínima de contraseña
  if (nueva_contraseña.length < 6) {
    return res.status(400).send('La contraseña debe tener al menos 6 caracteres');
  }
  
  try {
    // Buscar usuario con ese token y que no haya expirado
    db.query(
      'SELECT * FROM Usuario WHERE reset_token = ? AND reset_token_expiration > ?',
      [token, Date.now()],
      async (err, results) => {
        if (err) {
          console.error('Error en la consulta:', err);
          return res.status(500).send('Error interno');
        }
        
        if (results.length === 0) {
          return res.status(400).send('Token inválido o expirado');
        }
        
        const Usuario = results[0];
        
        // Encriptar nueva contraseña
        const contraseña = await bcrypt.hash(nueva_contraseña, 10);
        
        // Actualizar contraseña y eliminar token
        db.query(
          'UPDATE Usuario SET contraseña = ?, reset_token = NULL, reset_token_expiration = NULL WHERE id = ?',
          [contraseña, Usuario.id],
          (updateErr) => {
            if (updateErr) {
              console.error('Error al actualizar contraseña:', updateErr);
              return res.status(500).send('Error interno');
            }
            
            res.status(200).send('Contraseña actualizada correctamente');
          }
        );
      }
    );
  } catch (error) {
    console.error('Error en reset-password:', error);
    res.status(500).send('Error interno');
  }
});

module.exports = router;


