// C:\Users\STEV\Downloads\Proyecto-backend\routes\login.js
const express = require('express');
const router = express.Router();
const { pool } = require('../config/db'); // ¡Ruta correcta para acceder a db.js!
const bcrypt = require('bcrypt');

router.post('/login', async (req, res) => {
    const { correo_electronico, contraseña } = req.body;
    if (!correo_electronico || !contraseña) {
        return res.status(400).json({ message: 'Email y contraseña son requeridos.' });
    }
    try {
        const [users] = await pool.query('SELECT * FROM Usuario WHERE correo_electronico = ?', [correo_electronico]);
        if (users.length === 0) {
            return res.status(401).json({ message: 'Credenciales inválidas.' });
        }
        const user = users[0];
        const isMatch = await bcrypt.compare(contraseña, user.contraseña);
        if (!isMatch) {
            return res.status(401).json({ message: 'Credenciales inválidas.' });
        }
        // Aquí podrías generar un token JWT
        return res.status(200).json({ message: 'Inicio de sesión exitoso!', userId: user.id });
    } catch (err) {
        console.error('Error al iniciar sesión:', err);
        return res.status(500).json({ message: 'Error interno del servidor.' });
    }
});

module.exports = router;